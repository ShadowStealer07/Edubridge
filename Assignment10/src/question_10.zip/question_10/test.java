package question_10;

public class test {

}
